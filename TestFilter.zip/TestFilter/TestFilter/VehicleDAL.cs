﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestFilter;

namespace TestFilter
{
    public class VehicleDAL
    {


        /// <summary>
        /// 
        /// </summary>
        /// <param name="vehicleId"></param>
        /// <returns></returns>
        public static VehicleBO getVehicle(int vehicleId)
        {
            VehicleBO returnValue = null;
            

            using (EntitiesModelTest db = new EntitiesModelTest())
            {
                IEnumerable<VehicleBO> vehicles = db.GetVehicle(vehicleId);
                if (vehicles.Count() > 0)
                {
                    returnValue = vehicles.First();
                }
            }

            return returnValue;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="vehicleId"></param>
        /// <param name="uui"></param>
        public static void deleteVehicle(VehicleBO vehicle)
        {
            using (EntitiesModelTest db = new EntitiesModelTest())
            {
                //db.DeleteVehicle(
                //    vehicle.VehicleId,
                //    vehicle.Uui);

                db.SaveChanges();
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="vehicle"></param>
        public static int updateVehicle(VehicleBO vehicle)
        {
            int returnValue = -1;
            using (EntitiesModelTest db = new EntitiesModelTest())
            {
                returnValue = db.UpdateVehicle(
                    vehicle.VehicleId,
                    vehicle.NumberPlate,
                    vehicle.WeightFrontAxel,
                    vehicle.CostsPerKm
                     );

                db.SaveChanges();
            }
            return returnValue;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="vehicle"></param>
        public static int insertVehicle(VehicleBO vehicle)
        {
            int? nId = -1;

            using (EntitiesModelTest db = new EntitiesModelTest())
            {
                db.InsertVehicle(
                    vehicle.NumberPlate,
                    vehicle.WeightFrontAxel,
                    vehicle.CostsPerKm, 
                    ref nId
                );



                db.SaveChanges();
            }
            return nId.Value;
        }
    }
}
